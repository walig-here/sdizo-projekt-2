#include "graphs/Graph.h"

EdgeData::EdgeData(unsigned begin, unsigned end, int weigth){

    this->begin = begin;
    this->end = end;
    this->weigth = weigth;

}